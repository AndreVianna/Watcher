﻿using Watcher.Hub.Commands;

// ToDo:
// 1. Read from the configuration the connection information of a list of possible daemons.
// 2. Open the connection and report if the connection failed.

MainCommand main = new();

main.Execute(args);
